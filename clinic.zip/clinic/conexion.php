<?php
    function getConexion() {
        $host = "localhost";
        $user = "root";
        $password = "";
        $database = "clinica";
        $port = 3306;
        return mysqli_connect($host, $user, $password, $database, $port);
    }
?>