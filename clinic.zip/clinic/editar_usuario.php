<?php 
    header('Content-Type: application/json');

    $id_paciente = $_GET['id_paciente'] ?? null;
    $nombres = $_GET['nombres'] ?? null;
    $apellidos = $_GET['apellidos'] ?? null;
    $telefono = $_GET['telefono'] ?? null;
    $numeroDocumento = $_GET['numeroDocumento'] ?? null;

    if (!$id_paciente || !$nombres || !$apellidos || !$telefono || !$numeroDocumento) {
        echo json_encode([
            'success' => false,
            'message' => 'Faltan datos requeridos.'
        ]);
        exit;
    }

    require_once("modelo/paciente.php");
    $rpta = EditarUsuario($id_paciente, $nombres, $apellidos, $telefono, $numeroDocumento);

    echo json_encode($rpta);
?>