<?php
require_once("modelo/marca.php");
$rpta = MostrarMarca();
echo json_encode($rpta);
?>