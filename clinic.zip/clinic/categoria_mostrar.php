<?php
require_once("modelo/categoria.php");
$rpta = MostrarCategoria();
echo json_encode($rpta);
?>