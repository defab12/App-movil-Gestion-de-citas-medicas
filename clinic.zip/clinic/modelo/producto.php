<?php 
function GuardarProducto($codigo,$nombre,$descripcion,$preComp,$preVent,$idCategoria,$idMarca)
{
    //Estableciendo la conexión a la BD
    require_once("conexion.php");

    $sql = "INSERT INTO producto() VALUES(
    null,
    '$idCategoria',
    '$idMarca',
    '$codigo',
    '$nombre',
    '$descripcion',
    '$preComp',
    '$preVent',
    0,
    1
    )";

    //ejecuta la consulta
    $result = mysqli_query($con,$sql);

    if(!$result) //si es false
    {
        $mensaje = "No se pudo registrar.";
    }
    else
    {
        $mensaje = "Se registró correctamente";
    }

    //cerrar conexión BD
    mysqli_close($con);

    return $mensaje;

}

function MostrarMarca()
{
    //Estableciendo la conexión a la BD
    require_once("conexion.php");

    //consulta SQL
    $sql = "SELECT id_marca as id, nom_marca as nombre 
    FROM marca";
    
    //Ejecución de consulta SQL
    $result = mysqli_query($con,$sql);

    $datos = array();
    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
    {
        $datos[] =  $row; 
    }

    //cerrar la conexion a BD
    mysqli_close($con);

    return $datos;
}

function EliminarContacto($idCont)
{
    //Estableciendo la conexión a la BD
    require_once("conexion.php");

    $sql = "DELETE FROM contacto WHERE id_contacto = '$idCont'";

    //ejecuta la consulta
    $result = mysqli_query($con,$sql);

    if(!$result) //si es false
    {
        $mensaje = "No se pudo eliminar.";
    }
    else
    {
        $mensaje = "Se eliminó correctamente";
    }

    //cerrar conexión BD
    mysqli_close($con);

    return $mensaje;

}

function ConsultarContacto($idCont)
{
    //Estableciendo la conexión a la BD
    require_once("conexion.php");

    //consulta SQL
    $sql = "SELECT * FROM contacto WHERE id_contacto = '$idCont'";
    
    //Ejecución de consulta SQL
    $result = mysqli_query($con,$sql);

    $datos = array();
    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
    {
        $datos[] =  $row; 
    }

    //cerrar la conexion a BD
    mysqli_close($con);

    return $datos;
}

function ActualizarContacto($idCont,$nombres,$apaterno,$amaterno,$documento,$celular,$correo,$direccion)
{
    //Estableciendo la conexión a la BD
    require_once("conexion.php");

    $sql = "UPDATE contacto SET 
    nom_contacto = '$nombres',
    ap_contacto = '$apaterno',
    am_contacto = '$amaterno',
    doc_contacto = '$documento',
    cel_contacto = '$celular',
    em_contacto = '$correo',
    dir_contacto = '$direccion'
    WHERE id_contacto = '$idCont'
    ";

    //ejecuta la consulta
    $result = mysqli_query($con,$sql);

    if(!$result) //si es false
    {
        $mensaje = "No se pudo actualizar.";
    }
    else
    {
        $mensaje = "Se actualizó correctamente";
    }

    //cerrar conexión BD
    mysqli_close($con);

    return $mensaje;

}
?>