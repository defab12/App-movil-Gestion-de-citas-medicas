<?php
    function ExisteUsuario($email) {
        require_once("conexion.php");
        $con = getConexion();

        $stmt = $con -> prepare("SELECT * FROM paciente WHERE email = ?");
        $stmt -> bind_param("s", $email);
        $stmt -> execute();
        $stmt -> store_result();

        $exist = $stmt -> num_rows > 0;

        $stmt -> close();
        $con -> close();
        return $exist;
    }

    function Login($email, $password) {
        require_once("conexion.php");
        $con = getConexion();

        $stmt = $con -> prepare("SELECT id_paciente, password, nombre, apellido FROM paciente WHERE email = ?");
        $stmt -> bind_param("s", $email);
        $stmt -> execute();
        $result = $stmt -> get_result();

        if ($result -> num_rows === 1) {
            $usuario = $result -> fetch_assoc();
            if (password_verify($password, $usuario['password'])) {
                return [
                    'success' => true,
                    'message' => "Login exitoso.",
                    "data" => [
                        'id_paciente' => $usuario['id_paciente'],
                        'nombre' => $usuario['nombre'],
                        'apellido' => $usuario['apellido']
                    ]
                ];
            } else {
                return [
                    'success' => false,
                    'message' => "Contraseña incorrecta."
                ];
            }
        } else {
            return [
                'success' => false,
                'message' => "El usuario no existe."
            ];
        }

        $stmt -> close();
        $con -> close();
    }
    
    function RegistrarUsuario($nombres, $apellidos, $email, $password) {
        require_once("conexion.php");
        if (ExisteUsuario($email)) {
            return [
                'success' => false,
                'message' => 'Ya existe un usuario con este email'
            ];
        }
        
        $con = getConexion();
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $con -> prepare("INSERT INTO paciente (nombre, apellido, email, password) VALUES (?, ?, ?, ?)");
        $stmt -> bind_param("ssss", $nombres, $apellidos, $email, $passwordHash);
        $result = $stmt -> execute();

        if ($result) {
            $idPaciente = $stmt -> insert_id;
            $res = [
                'success' => true,
                'message' => "Usuario registrado correctamente.",
                'id_paciente' => $idPaciente
            ];
        } else {
            $res = [
                'success' => false,
                'message' => "Error al registrar el usuario."
            ];
        }

        $stmt -> close();
        $con -> close();

        return $res;
    }
    
    function ObtenerUsuario($id_paciente) {
        require_once("conexion.php");
        $con = getConexion();

        $stmt = $con -> prepare("SELECT id_paciente, nombre, apellido, dni, telefono, email FROM paciente WHERE id_paciente = ?");
        $stmt -> bind_param("i", $id_paciente);
        $stmt -> execute();
        $result = $stmt -> get_result();

        if ($result -> num_rows === 1) {
            $usuario = $result -> fetch_assoc();
            $res = [
                'success' => true,
                'message' => "Usuario encontrado.",
                "data" => [
                    'id_paciente' => $usuario['id_paciente'],
                    'nombre' => $usuario['nombre'],
                    'apellido' => $usuario['apellido'],
                    'dni' => $usuario['dni'],
                    'telefono' => $usuario['telefono']
                ]
            ];
        } else {
            $res = [
                'success' => false,
                'message' => "El usuario no existe."
            ];
        }

        $stmt -> close();
        $con -> close();

        return $res;
    }

    function EditarUsuario($id_paciente, $nombres, $apellidos, $telefono, $numeroDocumento) {
        require_once("conexion.php");
        
        $con = getConexion();
        $stmt = $con -> prepare("UPDATE paciente SET nombre = ?, apellido = ?, telefono = ?, dni = ? WHERE id_paciente = ?");
        $stmt -> bind_param("ssssi", $nombres, $apellidos, $telefono, $numeroDocumento, $id_paciente);
        $result = $stmt -> execute();

        if ($result) {
            $res = [
                'success' => true,
                'message' => "Usuario editado correctamente.",
            ];
        } else {
            $res = [
                'success' => false,
                'message' => "Error al editar el usuario."
            ];
        }

        $stmt -> close();
        $con -> close();

        return $res;
    }
?>