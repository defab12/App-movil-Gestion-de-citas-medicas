<?php
function MostrarProducto()
{
    require_once("conexion.php");

    $sql = "SELECT 
                p.id_producto AS id,
                p.cod_producto,
                p.nom_producto,
                p.des_producto AS descrip,
                c.nom_categoria AS categoria,
                m.nom_marca AS marca,
                p.pco_producto AS pcompra,
                p.pve_producto AS pventa
            FROM producto p
            INNER JOIN categoria c ON p.id_categoria = c.id_categoria
            INNER JOIN marca m ON p.id_marca = m.id_marca";
  

    $result = mysqli_query($con, $sql);

    $datos = array();
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $datos[] = $row;
    }

    mysqli_close($con);

    return $datos;
}
?>