<?php 
//recibe datos desde Android
$codigo = $_GET['codigo'];
$nombre = $_GET['nombre'];
$descripcion = $_GET['descripcion'];
$preComp = $_GET['preComp'];
$preVent = $_GET['preVent'];
$idCategoria = $_GET['idCategoria'];
$idMarca = $_GET['idMarca'];

//Registra datos en la BD
require_once("modelo/producto.php");
$rpta = GuardarProducto($codigo,$nombre,$descripcion,$preComp,$preVent,$idCategoria,$idMarca);

//Responde a Android
echo $rpta;
?>