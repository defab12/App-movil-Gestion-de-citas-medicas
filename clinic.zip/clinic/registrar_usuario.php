<?php 
    header('Content-Type: application/json');

    $nombres = $_GET['nombres'] ?? null;
    $apellidos = $_GET['apellidos'] ?? null;
    $email = $_GET['email'] ?? null;
    $password = $_GET['password'] ?? null;

    if (!$nombres || !$apellidos || !$email || !$password) {
        echo json_encode([
            'success' => false,
            'message' => 'Faltan datos requeridos.'
        ]);
        exit;
    }

    require_once("modelo/paciente.php");
    $rpta = RegistrarUsuario($nombres, $apellidos, $email, $password);

    echo json_encode($rpta);
?>