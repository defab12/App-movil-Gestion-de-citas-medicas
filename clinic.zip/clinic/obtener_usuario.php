<?php 
    header('Content-Type: application/json');

    $id_paciente = $_GET['id_paciente'] ?? null;

    require_once("modelo/paciente.php");
    $rpta = ObtenerUsuario($id_paciente);

    echo json_encode($rpta);
?>