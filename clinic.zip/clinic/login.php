<?php 
    header('Content-Type: application/json');

    $email = $_GET['email'] ?? null;
    $password = $_GET['password'] ?? null;

    if (!$email || !$password) {
        echo json_encode([
            'success' => false,
            'message' => 'Faltan datos: email o contraseña'
        ]);

        exit;
    }

    require_once("modelo/paciente.php");
    $rpta = Login($email, $password);

    echo json_encode($rpta);
?>